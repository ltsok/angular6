export class Hero {
    public id:Number;
    public name:String
}